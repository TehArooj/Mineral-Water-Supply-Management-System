create view stock as
select `mwms`.`stock_receipt`.`REC_ID`              AS `DOC_ID`,
       `mwms`.`stock_receipt`.`REC_DATE`            AS `DOC_DATE`,
       'STOCK IN'                                   AS `NARRATION`,
       `mwms`.`stock_receipt`.`PRODUCT_ID`          AS `PRODUCT_ID`,
       ifnull(`mwms`.`stock_receipt`.`QUANTITY`, 0) AS `QTY_IN`,
       0                                            AS `QTY_OUT`
from `mwms`.`stock_receipt`
union all
select `mwms`.`orders`.`ORDER_ID`            AS `DOC_ID`,
       `mwms`.`orders`.`ORDER_DATE`          AS `DOC_DATE`,
       'STOCK OUT'                           AS `NARRATION`,
       `mwms`.`orders`.`PRODUCT_ID`          AS `PRODUCT_ID`,
       0                                     AS `QTY_IN`,
       ifnull(`mwms`.`orders`.`QUANTITY`, 0) AS `QTY_OUT`
from `mwms`.`orders`
where `mwms`.`orders`.`STATUS` in ('DELIVERED', 'BILLED');

